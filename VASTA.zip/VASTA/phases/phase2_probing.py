"""
Phase 2 — Live Host / Port Probing
====================================
Filters subdomains to those that actually respond using httpx.
"""

import os
from typing import Dict, Callable
import time

from phases.base_phase import BasePhase, PhaseResult


class ProbingPhase(BasePhase):
    """Phase 2: Live Host / Port Probing."""

    def __init__(self):
        super().__init__(
            phase_id=2,
            name="Live Host Probing",
            description="Filter hosts that respond on ports 80, 443, 8080, 8000, 8888",
            required_tools=["httpx"],
        )

    def run(
        self,
        target: str,
        output_dir: str,
        previous_results: Dict[str, str],
        on_output: Callable[[str], None],
    ) -> PhaseResult:
        start = time.time()
        errors = []
        alive_file = os.path.join(output_dir, "subdomain_alive.txt")

        # Get input from Phase 1
        all_subs = previous_results.get("all_subdomains", "")
        if not self._file_exists_with_content(all_subs):
            on_output("[!] No subdomains file found from Phase 1")
            errors.append("Missing input: all_subdomains.txt")
            self._ensure_file(alive_file)
            return PhaseResult(
                phase_id=self.phase_id,
                phase_name=self.name,
                success=False,
                output_files={"subdomain_alive": alive_file},
                stats={"alive_hosts": 0},
                duration=time.time() - start,
                errors=errors,
            )

        # Run httpx probing
        if not self._cancelled:
            on_output("[*] Probing live hosts with httpx...")
            cmd = (
                f"httpx -l {all_subs} "
                f"-ports 80,443,8080,8000,8888 "
                f"-threads 200 "
                f"-o {alive_file}"
            )
            rc = self._run_cmd(cmd, on_output, timeout=900)
            if rc != 0:
                errors.append("httpx returned non-zero exit code")
                self._ensure_file(alive_file)

        total_subs = self._file_line_count(all_subs)
        alive_count = self._file_line_count(alive_file)
        on_output(f"  [✓] Alive hosts: {alive_count}/{total_subs}")

        return PhaseResult(
            phase_id=self.phase_id,
            phase_name=self.name,
            success=alive_count > 0 or not errors,
            output_files={"subdomain_alive": alive_file},
            stats={"alive_hosts": alive_count},
            duration=time.time() - start,
            errors=errors,
        )
