"""
Phase 7 — Active Vulnerability Scanning
=========================================
Runs 8 targeted vulnerability scanners against bucketed URL lists.
"""

import os
from typing import Dict, Callable, List
import time

from phases.base_phase import BasePhase, PhaseResult
from core.result_parser import Vulnerability, ResultParser


class ScanningPhase(BasePhase):
    """Phase 7: Active Vulnerability Scanning with 8 tools."""

    def __init__(self):
        super().__init__(
            phase_id=7,
            name="Active Scanning",
            description="Run targeted scanners against bucketed URL lists",
            required_tools=[
                "dalfox", "sqlmap", "LFI-FINDER", "OpenRedireX",
                "http-request-smuggling", "headi", "CORStest", "toxicache",
            ],
        )
        self._parser = ResultParser()

    def run(
        self,
        target: str,
        output_dir: str,
        previous_results: Dict[str, str],
        on_output: Callable[[str], None],
    ) -> PhaseResult:
        start = time.time()
        errors = []
        all_vulns: List[Vulnerability] = []
        stats = {}
        project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        tools_dir = os.path.join(project_dir, "tools")

        on_output("[*] Starting active vulnerability scanning...")
        on_output("[*] Only running scanners where input files have content\n")

        # ── 1. XSS — dalfox ────────────────────────────────────
        xss_file = previous_results.get("xss", "")
        if not self._cancelled and self._file_exists_with_content(xss_file):
            on_output("[*] [1/8] XSS Scanning with dalfox...")
            dalfox_out = os.path.join(output_dir, "dalfox_results.txt")
            cmd = f"dalfox file {xss_file} -o {dalfox_out} --silence"
            rc = self._run_cmd(cmd, on_output, timeout=1800)
            if rc != 0:
                errors.append("dalfox encountered errors")
            self._ensure_file(dalfox_out)
            vulns = self._parser.parse_dalfox_output(dalfox_out)
            all_vulns.extend(vulns)
            stats["xss_vulns"] = len(vulns)
            on_output(f"  [{'✓' if vulns else '-'}] dalfox found {len(vulns)} XSS vulnerabilities")
        else:
            on_output("[*] [1/8] XSS — skipped (no XSS URLs to scan)")
            stats["xss_vulns"] = 0

        # ── 2. SQLi — sqlmap ───────────────────────────────────
        sqli_file = previous_results.get("sqli", "")
        if not self._cancelled and self._file_exists_with_content(sqli_file):
            on_output("[*] [2/8] SQL Injection scanning with sqlmap...")
            sqlmap_dir = os.path.join(output_dir, "sqlmap")
            os.makedirs(sqlmap_dir, exist_ok=True)
            cmd = (
                f"sqlmap -m {sqli_file} "
                f"--batch --level 2 --risk 2 "
                f"--output-dir={sqlmap_dir} "
                f"--threads 4"
            )
            rc = self._run_cmd(cmd, on_output, timeout=3600)
            if rc != 0:
                errors.append("sqlmap encountered errors")
            vulns = self._parser.parse_sqlmap_output(sqlmap_dir)
            all_vulns.extend(vulns)
            stats["sqli_vulns"] = len(vulns)
            on_output(f"  [{'✓' if vulns else '-'}] sqlmap found {len(vulns)} SQLi vulnerabilities")
        else:
            on_output("[*] [2/8] SQLi — skipped (no SQLi URLs to scan)")
            stats["sqli_vulns"] = 0

        # ── 3. LFI — LFI-FINDER ──────────────────────────────
        lfi_file = previous_results.get("lfi", "")
        if not self._cancelled and self._file_exists_with_content(lfi_file):
            lfi_dir = os.path.join(tools_dir, "LFI-FINDER")
            if os.path.isdir(lfi_dir):
                on_output("[*] [3/8] LFI scanning with LFI-FINDER...")
                lfi_out = os.path.join(output_dir, "lfi_results.txt")
                # Find the main script
                script = self._find_script(lfi_dir, ["lfi_finder.py", "lfi-finder.py", "main.py"])
                if script:
                    cmd = f"python3 {script} -f {lfi_file} > {lfi_out} 2>&1 || true"
                    self._run_cmd(cmd, on_output, timeout=900)
                    self._ensure_file(lfi_out)
                    vulns = self._parser.parse_generic_scanner_output(
                        lfi_out, "LFI", "LFI-FINDER", "high"
                    )
                    all_vulns.extend(vulns)
                    stats["lfi_vulns"] = len(vulns)
                    on_output(f"  [{'✓' if vulns else '-'}] LFI-FINDER found {len(vulns)} findings")
                else:
                    on_output("  [!] LFI-FINDER script not found")
                    stats["lfi_vulns"] = 0
            else:
                on_output("[*] [3/8] LFI — skipped (LFI-FINDER not installed)")
                stats["lfi_vulns"] = 0
        else:
            on_output("[*] [3/8] LFI — skipped (no LFI URLs to scan)")
            stats["lfi_vulns"] = 0

        # ── 4. Open Redirect — OpenRedireX ────────────────────
        redirect_file = previous_results.get("redirect", "")
        if not self._cancelled and self._file_exists_with_content(redirect_file):
            orx_dir = os.path.join(tools_dir, "OpenRedireX")
            if os.path.isdir(orx_dir):
                on_output("[*] [4/8] Open Redirect scanning with OpenRedireX...")
                redirect_out = os.path.join(output_dir, "openredirex_results.txt")
                script = self._find_script(orx_dir, ["openredirex.py", "main.py"])
                payloads = os.path.join(orx_dir, "payloads.txt")
                if script:
                    payload_arg = f"-p {payloads}" if os.path.exists(payloads) else ""
                    cmd = f"python3 {script} -l {redirect_file} {payload_arg} > {redirect_out} 2>&1 || true"
                    self._run_cmd(cmd, on_output, timeout=900)
                    self._ensure_file(redirect_out)
                    vulns = self._parser.parse_generic_scanner_output(
                        redirect_out, "Open Redirect", "OpenRedireX", "medium"
                    )
                    all_vulns.extend(vulns)
                    stats["redirect_vulns"] = len(vulns)
                    on_output(f"  [{'✓' if vulns else '-'}] OpenRedireX found {len(vulns)} findings")
                else:
                    on_output("  [!] OpenRedireX script not found")
                    stats["redirect_vulns"] = 0
            else:
                on_output("[*] [4/8] Open Redirect — skipped (OpenRedireX not installed)")
                stats["redirect_vulns"] = 0
        else:
            on_output("[*] [4/8] Open Redirect — skipped (no redirect URLs)")
            stats["redirect_vulns"] = 0

        # ── 5. Request Smuggling ──────────────────────────────
        alive_file = previous_results.get("subdomain_alive", "")
        if not self._cancelled and self._file_exists_with_content(alive_file):
            smuggling_dir = os.path.join(tools_dir, "http-request-smuggling")
            if os.path.isdir(smuggling_dir):
                on_output("[*] [5/8] Request Smuggling scanning...")
                smuggling_out = os.path.join(output_dir, "smuggling_results.txt")
                script = self._find_script(smuggling_dir, ["smuggler.py", "main.py"])
                if script:
                    cmd = f"python3 {script} -l {alive_file} > {smuggling_out} 2>&1 || true"
                    self._run_cmd(cmd, on_output, timeout=900)
                    self._ensure_file(smuggling_out)
                    vulns = self._parser.parse_generic_scanner_output(
                        smuggling_out, "Request Smuggling", "http-request-smuggling", "high"
                    )
                    all_vulns.extend(vulns)
                    stats["smuggling_vulns"] = len(vulns)
                else:
                    stats["smuggling_vulns"] = 0
            else:
                on_output("[*] [5/8] Request Smuggling — skipped (tool not installed)")
                stats["smuggling_vulns"] = 0
        else:
            on_output("[*] [5/8] Request Smuggling — skipped (no alive hosts)")
            stats["smuggling_vulns"] = 0

        # ── 6. Header Injection — headi ──────────────────────
        mainurls = previous_results.get("mainurls", "")
        if not self._cancelled and self._file_exists_with_content(mainurls):
            on_output("[*] [6/8] Header Injection scanning with headi...")
            headi_out = os.path.join(output_dir, "headi_results.txt")
            cmd = f"headi -url {mainurls} > {headi_out} 2>&1 || true"
            rc = self._run_cmd(cmd, on_output, timeout=900)
            self._ensure_file(headi_out)
            vulns = self._parser.parse_generic_scanner_output(
                headi_out, "Header Injection", "headi", "medium"
            )
            all_vulns.extend(vulns)
            stats["header_vulns"] = len(vulns)
            on_output(f"  [{'✓' if vulns else '-'}] headi found {len(vulns)} findings")
        else:
            on_output("[*] [6/8] Header Injection — skipped")
            stats["header_vulns"] = 0

        # ── 7. CORS — CORStest ───────────────────────────────
        cors_file = previous_results.get("cors", "")
        if not self._cancelled and self._file_exists_with_content(cors_file):
            cors_dir = os.path.join(tools_dir, "CORStest")
            if os.path.isdir(cors_dir):
                on_output("[*] [7/8] CORS misconfiguration scanning...")
                cors_out = os.path.join(output_dir, "corstest_results.txt")
                script = self._find_script(cors_dir, ["corstest.py", "cors_scan.py", "main.py"])
                if script:
                    cmd = f"python3 {script} -i {cors_file} > {cors_out} 2>&1 || true"
                    self._run_cmd(cmd, on_output, timeout=900)
                    self._ensure_file(cors_out)
                    vulns = self._parser.parse_generic_scanner_output(
                        cors_out, "CORS", "CORStest", "medium"
                    )
                    all_vulns.extend(vulns)
                    stats["cors_vulns"] = len(vulns)
                else:
                    stats["cors_vulns"] = 0
            else:
                on_output("[*] [7/8] CORS — skipped (CORStest not installed)")
                stats["cors_vulns"] = 0
        else:
            on_output("[*] [7/8] CORS — skipped (no CORS URLs)")
            stats["cors_vulns"] = 0

        # ── 8. Cache Poisoning — toxicache ────────────────────
        cache_file = previous_results.get("cache", "")
        # Also try mainurls if no specific cache file
        if not cache_file or not self._file_exists_with_content(cache_file):
            cache_file = previous_results.get("mainurls", "")
        if not self._cancelled and self._file_exists_with_content(cache_file):
            on_output("[*] [8/8] Cache Poisoning scanning with toxicache...")
            cache_out = os.path.join(output_dir, "toxicache_results.txt")
            cmd = f"toxicache -l {cache_file} > {cache_out} 2>&1 || true"
            rc = self._run_cmd(cmd, on_output, timeout=900)
            self._ensure_file(cache_out)
            vulns = self._parser.parse_generic_scanner_output(
                cache_out, "Cache Poisoning", "toxicache", "medium"
            )
            all_vulns.extend(vulns)
            stats["cache_vulns"] = len(vulns)
            on_output(f"  [{'✓' if vulns else '-'}] toxicache found {len(vulns)} findings")
        else:
            on_output("[*] [8/8] Cache Poisoning — skipped")
            stats["cache_vulns"] = 0

        # Summary
        total_vulns = len(all_vulns)
        on_output(f"\n  [✓] Active scanning complete: {total_vulns} total vulnerabilities found")

        if all_vulns:
            # Breakdown
            severity_counts = {}
            for v in all_vulns:
                sev = v.severity
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
            for sev, count in sorted(severity_counts.items()):
                on_output(f"      {sev.upper()}: {count}")

        return PhaseResult(
            phase_id=self.phase_id,
            phase_name=self.name,
            success=True,
            output_files={},
            stats=stats,
            vulnerabilities=all_vulns,
            duration=time.time() - start,
            errors=errors,
        )

    @staticmethod
    def _find_script(directory: str, script_names: List[str]) -> str:
        """Find the first matching script in a directory."""
        for name in script_names:
            path = os.path.join(directory, name)
            if os.path.exists(path):
                return path
        # Search recursively
        for root, dirs, files in os.walk(directory):
            for name in script_names:
                if name in files:
                    return os.path.join(root, name)
        return ""
