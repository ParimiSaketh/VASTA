"""
Phase 4 — Sensitive File / JS Discovery
=========================================
Surfaces JS files and exposed sensitive file extensions.
Optionally runs gitGraber, zip-finder, and 4-ZERO-3.
"""

import os
from typing import Dict, Callable
import time

from phases.base_phase import BasePhase, PhaseResult


class SensitivePhase(BasePhase):
    """Phase 4: Sensitive File / JS Discovery."""

    def __init__(self):
        super().__init__(
            phase_id=4,
            name="Sensitive File Discovery",
            description="Surface JS files and exposed sensitive extensions",
            required_tools=[],
        )

    def run(
        self,
        target: str,
        output_dir: str,
        previous_results: Dict[str, str],
        on_output: Callable[[str], None],
    ) -> PhaseResult:
        start = time.time()
        errors = []
        js_file = os.path.join(output_dir, "js.txt")
        sensitive_file = os.path.join(output_dir, "sensitive_files.txt")

        mainurls = previous_results.get("mainurls", "")
        if not self._file_exists_with_content(mainurls):
            on_output("[!] No mainurls file from Phase 3")
            errors.append("Missing input: mainurls.txt")
            self._ensure_file(js_file)
            self._ensure_file(sensitive_file)
            return PhaseResult(
                phase_id=self.phase_id,
                phase_name=self.name,
                success=False,
                output_files={"js_files": js_file, "sensitive_files": sensitive_file},
                stats={"js_files": 0, "sensitive_files": 0},
                duration=time.time() - start,
                errors=errors,
            )

        # Step 1: Extract JS files
        if not self._cancelled:
            on_output("[*] Extracting JavaScript file URLs...")
            cmd = f"grep -iE '\\.js(\\?|$)' {mainurls} > {js_file} || true"
            self._run_cmd(cmd, on_output)
            self._ensure_file(js_file)
            js_count = self._file_line_count(js_file)
            on_output(f"  [+] Found {js_count} JS files")

        # Step 2: Extract sensitive file extensions
        if not self._cancelled:
            on_output("[*] Extracting sensitive file URLs...")
            extensions = (
                r"\.(txt|log|cache|secret|db|backup|yml|yaml|json|gz|rar|zip|"
                r"config|bak|old|sql|env|key|pem|cfg)(\?|$)"
            )
            cmd = f"grep -iE '{extensions}' {mainurls} > {sensitive_file} || true"
            self._run_cmd(cmd, on_output)
            self._ensure_file(sensitive_file)
            sens_count = self._file_line_count(sensitive_file)
            on_output(f"  [+] Found {sens_count} sensitive files")

        # Step 3: Optional tools (git-cloned)
        project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        tools_dir = os.path.join(project_dir, "tools")

        # gitGraber (needs API tokens, skip if not configured)
        if not self._cancelled:
            gitgraber_dir = os.path.join(tools_dir, "gitGraber")
            if os.path.isdir(gitgraber_dir):
                on_output("[*] gitGraber found — skipping (requires GitHub API token config)")

        # zip-finder
        if not self._cancelled:
            zipfinder_dir = os.path.join(tools_dir, "zip-finder")
            alive_file = previous_results.get("subdomain_alive", "")
            if os.path.isdir(zipfinder_dir) and self._file_exists_with_content(alive_file):
                on_output("[*] Running zip-finder for archive exposure...")
                zip_results = os.path.join(output_dir, "zip_finder_results.txt")
                # Find the main script
                for script_name in ["zipfinder.py", "zip-finder.py", "main.py"]:
                    script = os.path.join(zipfinder_dir, script_name)
                    if os.path.exists(script):
                        cmd = f"python3 {script} -l {alive_file} > {zip_results} 2>&1 || true"
                        self._run_cmd(cmd, on_output, timeout=300)
                        break
            else:
                on_output("[*] zip-finder not installed — skipping")

        # 4-ZERO-3 (403 bypass)
        if not self._cancelled:
            four_zero_dir = os.path.join(tools_dir, "4-ZERO-3")
            if os.path.isdir(four_zero_dir):
                on_output("[*] 4-ZERO-3 found — will be used in directory bruteforce phase")
            else:
                on_output("[*] 4-ZERO-3 not installed — skipping")

        js_count = self._file_line_count(js_file)
        sens_count = self._file_line_count(sensitive_file)
        on_output(f"  [✓] JS files: {js_count}, Sensitive files: {sens_count}")

        return PhaseResult(
            phase_id=self.phase_id,
            phase_name=self.name,
            success=True,
            output_files={
                "js_files": js_file,
                "sensitive_files": sensitive_file,
            },
            stats={"js_files": js_count, "sensitive_files": sens_count},
            duration=time.time() - start,
            errors=errors,
        )
