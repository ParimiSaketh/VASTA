"""
Phase 5 — Directory & Content Bruteforce
==========================================
Finds hidden files and paths not caught by crawling using dirsearch.
"""

import os
from typing import Dict, Callable
import time

from phases.base_phase import BasePhase, PhaseResult


class DirBrutePhase(BasePhase):
    """Phase 5: Directory & Content Bruteforce."""

    def __init__(self):
        super().__init__(
            phase_id=5,
            name="Directory Bruteforce",
            description="Find hidden files/paths not caught by crawling",
            required_tools=["dirsearch"],
        )

    def run(
        self,
        target: str,
        output_dir: str,
        previous_results: Dict[str, str],
        on_output: Callable[[str], None],
    ) -> PhaseResult:
        start = time.time()
        errors = []
        dirsearch_file = os.path.join(output_dir, "dirsearch_results.txt")

        alive_file = previous_results.get("subdomain_alive", "")
        if not self._file_exists_with_content(alive_file):
            on_output("[!] No alive hosts file from Phase 2")
            errors.append("Missing input: subdomain_alive.txt")
            self._ensure_file(dirsearch_file)
            return PhaseResult(
                phase_id=self.phase_id,
                phase_name=self.name,
                success=False,
                output_files={"dirsearch_results": dirsearch_file},
                stats={"dirs_found": 0},
                duration=time.time() - start,
                errors=errors,
            )

        # Run dirsearch
        if not self._cancelled:
            on_output("[*] Running dirsearch for directory bruteforce...")
            extensions = (
                "conf,config,bak,backup,smp,old,db,sql,asp,aspx,py,rb,php,"
                "cache,cgi,csv,html,inc,jar,js,json,jsp,lock,log,rar,"
                "sql.gz,sql.zip,tar.gz,txt,wadl,zip,xml"
            )
            cmd = (
                f"dirsearch -l {alive_file} "
                f"-e {extensions} "
                f"-o {dirsearch_file} "
                f"--format plain "
                f"-t 50 "
                f"--no-color"
            )
            rc = self._run_cmd(cmd, on_output, timeout=3600)
            if rc != 0:
                errors.append("dirsearch returned non-zero exit code")
                self._ensure_file(dirsearch_file)

        dirs_count = self._file_line_count(dirsearch_file)
        on_output(f"  [✓] Directory bruteforce found {dirs_count} results")

        return PhaseResult(
            phase_id=self.phase_id,
            phase_name=self.name,
            success=True,
            output_files={"dirsearch_results": dirsearch_file},
            stats={"dirs_found": dirs_count},
            duration=time.time() - start,
            errors=errors,
        )
